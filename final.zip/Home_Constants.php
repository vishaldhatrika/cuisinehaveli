<?php
define('HOMEURL',"http://localhost/ch/");
?>