    <!-- footer starts-->
    <footer>
        <section class="social">
            <h3><a href="https://facebook.com/cuisinehaveli">
                    <!-- <img src="https://cdn1.iconfinder.com/data/icons/social-media-2285/512/Colored_Facebook3_svg-512.png"
                        alt="" class="socialicon"> Facebook</a> | -->
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Facebook_Logo_%282019%29.png/1024px-Facebook_Logo_%282019%29.png" alt="" class="socialicon">
                </a>

                <a href="https://instagram.com/cuisine.haveli">
                    <img src="https://cdn2.iconfinder.com/data/icons/social-media-2285/512/1_Instagram_colored_svg_1-512.png" alt="" class="socialicon"></a>
                <a href="https://twitter.com/cuisinehaveli">
                    <img src="https://cdn2.iconfinder.com/data/icons/social-media-2285/512/1_Twitter_colored_svg-512.png" alt="" class="socialicon"></a>
            </h3>
        </section>

        <style>
            .prof_link,
            .prof_link:visited {
                text-decoration: none;
                color: black;
                background-color: #D7FCD47F;
                padding: 3px;
                border-radius: 3px;
            }

            .prof_link:hover {
                color: darkgreen;
                background-color: #D7FCD4;
                text-decoration: underline;

            }
        </style>

        <section class="footerinfo">
            Content not copyrighted. Developed by <a href="https://vishaldhatrika.me" class="prof_link">Vishal Dhatrika</a>, <a href="https://www.linkedin.com/in/kaushik-gupta-199b52170/" class="prof_link">Kaushik Gupta</a>, <a href="https://www.linkedin.com/in/sai-yashwanth-reddy-gujjula-7ab360208" class="prof_link">Sai Yashwanth Reddy Gujjula</a> and <a href="https://www.linkedin.com/in/jala-rakesh-0429a41b1" class="prof_link">Jala Rakesh</a>, as an academic project.
        </section>

        <section class="sitedisclaimer">
            <div class="marquee">
                <p class="marquee__content">
                    &nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    This wesbite has been developed for EDUCATIONAL purposes only. We are neither associated with any restaurant, nor accept payments and orders.
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    This wesbite has been developed for EDUCATIONAL purposes only. We are neither associated with any restaurant, nor accept payments and orders.
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    This wesbite has been developed for EDUCATIONAL purposes only. We are neither associated with any restaurant, nor accept payments and orders.
                </p>
            </div>
        </section>
    </footer>
    <!-- footer ends-->



    </body>

    </html>